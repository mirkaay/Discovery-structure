Legacy checkout location (v3). With a sibling `dev/<tool>/<repo>` folder structure, leave this folder empty and use `config/repositories.json` instead. See `README.md`.
