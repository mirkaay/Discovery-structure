# Upgrade from v2 safely

**Do not blindly overwrite an in-use kit.** Back up `context/` (including reviewed system notes and `context/revisions.json`) and your `.github` customizations. This v3 ZIP contains only **template** context files and does not know about your actual system.

1. Extract v3 to a **separate directory** and review its new `README.md`.
2. Move/copy your existing *approved* `sources/` checkouts to the new location, or keep the original authorized checkouts and arrange an approved workspace; never ship them back in an archive.
3. Copy the verified **v2 `context/`** notes and revision manifest into v3. Check that repo relative paths and Git SHAs remain correct; if checkout paths change, treat the baseline as unverified and refresh.
4. Compare any locally customized `.github/copilot-instructions.md`, `.github/instructions/`, agents and skills before taking v3 defaults. Don't discard your company's rules.
5. In VS Code verify the four active agents are visible and the five optional roles are no longer active, then test a synthetic fixture before touching work code.
6. Run the local validators and a targeted context check. Do not use `capture --reviewed` to hide a stale snapshot.

For LIGHT/STANDARD tasks select **Feature Engineer**. For a DEEP task use architecture research, approval and review. Record observed cost in `BENCHMARK.md` instead of assuming improvements.
