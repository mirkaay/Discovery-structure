# Infrastructure Research + Feature Delivery Kit v4 (repo-first)

Use your existing folder hierarchy without moving or cloning repositories:

```text
dev/
  compliance-tool/
    repo-one/
    repo-two/
  dynatrace/
    repo-a/
    repo-b/
  gremlin/
    repo-c/
  infra-research-kit/   <-- this kit
```

## First-time setup

In a terminal opened in `dev/infra-research-kit/`:

```bash
python3 scripts/context_status.py discover
python3 scripts/context_status.py init --groups dynatrace gremlin compliance-tool
python3 scripts/context_status.py list
python3 scripts/create_workspaces.py
```

`discover` lists candidate repositories under sibling tool directories. `init` makes an **explicit allowlist**, which you should review to include only repositories permitted for AI-assisted analysis. Nothing moves, clones, fetches, commits, or pushes company repositories. `create_workspaces.py` creates `workspaces/dynatrace.code-workspace`, `workspaces/gremlin.code-workspace`, and so on, using **each repository as its own workspace root**. Workspaces stay in the kit and are ignored by the kit's Git rules.

Open `workspaces/dynatrace.code-workspace` in **VS Code editor's Chat** for cross-repo investigation. The included `Research Kit` root makes its custom agents and context files available; verify agent discovery in `Chat: Open Customizations` for your actual Copilot harness. Because agents can only use the context they are given, verify file references and permissions. The standalone Agents window may not support multi-root sessions.

For everyday feature development, you can **keep the Dynatrace workspace open** and edit/commit/push from the target repository: each root is a standalone Git repo. Check terminal working directory before running any git command. Use `Feature Engineer` and `prompts/09-feature-request.md`; tell it the target repo and branch explicitly. For a narrower session, open only that repo in a new VS Code window and use a **user-level** Feature Engineer created with `Chat: Open Customizations > Agents > New Agent > User` (copy from `.github/agents/feature-engineer.agent.md` if allowed). Since the kit's workspace instructions and notes won't automatically load in a repository-only window, attach the relevant approved `context/systems/<tool>.md` when useful.

## Monthly refresh / feature workflow

1. Use `Architecture Researcher` and `prompts/01-discover-repos.md` once per tool group. Review the evidence-backed notes and store them in `context/systems/<tool>.md`; update `context/index.md`.
2. After review and when all allowlisted working copies are clean, capture Git revisions: `python3 scripts/context_status.py capture --reviewed`.
3. Before a feature: `python3 scripts/context_status.py check --tool dynatrace --max-paths 8`. Code always beats cached notes; only inspect changed paths relevant to your task.
4. Run `Feature Engineer` on one named target repository. Scope edits and tests to that repo, review diff, then commit/push manually using your usual Git workflow. Update the context note only for an actual architecture change.

## Safety and limits

Use only employer-approved Copilot and repository access. No agent's language instructions form a security sandbox. Project agent access and permissions differ by harness and VS Code version. No cached note proves production runtime. Run tests and Git commands yourself unless you explicitly authorize and verify the appropriate tools and environment. Git `check` reads local metadata only; it never fetches remote changes. Pull/update refs through your existing team workflow. `capture --reviewed` records a snapshot baseline of approved code, not a semantic verification.

## Validate

```bash
python3 scripts/validate_kit.py
python3 -m unittest -v scripts/test_context_status.py
```

Other prompts, skills, test fixtures and benchmark instructions are preserved from v3.
