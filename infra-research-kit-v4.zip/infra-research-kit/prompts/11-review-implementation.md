# Optional independent review for tricky/DEEP changes

Use **Code Reviewer** (read/search only).

REQUIREMENT: [feature and acceptance criteria]
ACTUAL DIFF: [paste/attach, or point to exact changed files]
TEST OUTPUT: [actual logs or NOT RUN]

Find actionable correctness, security, compatibility, state, test or performance defects; identify needless complexity, dead code and duplicate patterns. Ground every finding in exact paths and mechanisms, prioritize, and give minimum fix. No generic style laundry lists; no editing or running commands. If no defect is found, state remaining verification limits.
