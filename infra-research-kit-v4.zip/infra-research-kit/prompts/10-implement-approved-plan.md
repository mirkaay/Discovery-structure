# Implement a high-risk / DEEP approved plan

Use **Feature Engineer**. This is for DEEP tasks requiring previous approval, not the default workflow.

APPROVED SCOPE: [plan and files]
REPOSITORY/BRANCH: [target]

Confirm plan still fits current code before edits. Implement minimum diff and tests using existing patterns. Do not add speculative abstractions, unreferenced code, unnecessary dependencies, broad exceptions, or unrelated refactoring. Preserve security, contracts and Terraform state safety. Never execute, deploy, push or commit. Return concise changed-file summary, repo-grounded test commands, unverified items and only a material architecture delta.
