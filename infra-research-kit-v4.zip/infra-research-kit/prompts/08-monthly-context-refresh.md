# Monthly context refresh prompt

Use **Context Maintainer** with read/search-only tools. Target system: [Dynatrace / other]. Previous notes: `context/index.md` and `context/systems/[system].md`. Source repositories: [list].

I have run `python3 scripts/context_status.py check`; here is the report: [PASTE OUTPUT].

Do a *delta-first* update: inspect changed paths, module imports/calls, CI/CD triggers, external contracts, deploy entry points, tests and any architectural changes. If code paths disappeared, mark the old assumptions invalid. Search more widely only where changes indicate a missing dependency. Show each material finding with current file/symbol/line and revision.

Deliver (a) the changed architecture edges, (b) a concise source-backed updated system page in the existing template, (c) a small index change only if routing/ownership changed, (d) missing runtime checks, and (e) manual review checklist. No edits, shell commands or snapshot promotion. The engineer will approve, save notes, and run `capture --reviewed` manually.
