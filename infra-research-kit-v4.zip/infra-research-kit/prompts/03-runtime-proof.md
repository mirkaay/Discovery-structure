# Prompt 03 — Compare repository intent to observed runtime

Scope: **[one monitored AKS cluster / one Synthetic monitor]**. Environment: **[name]**.
Evidence currently supplied: **[safe, redacted runtime screenshots, statuses or metrics; none if unknown]**.

Review the source-derived desired-state claims. Construct a desired-versus-observed matrix. For every unresolved connection, give the minimum read-only verification I can perform in approved tools: Kubernetes resource descriptions (not secrets), Operator/DynaKube condition and namespace, Helm release metadata, Dynatrace monitor status, execution-location classification, most recent executions and errors, problem-to-notification settings, and deployment pipeline record.

For each check supply: question, evidence source, necessary permission type, what a healthy observation would mean, alternative failure interpretations, and whether this step exposes sensitive data. Do not claim access you haven't got. Do not run commands or contact external systems unless I separately authorize a read-only tool. Do not propose terraform apply/refresh/plan, kubectl exec, port-forward, or any command that could lock state or create side effects. If querying an MCP server is permitted in a later session, insist on least-privilege and explicit allowlisting.

Output the final matrix and a remaining-unknown list. An HCL file or green dashboard alone cannot prove end-to-end functionality.
