# Optional architecture update only for substantive changes

Use **Context Maintainer** only when the actual change alters a system boundary, API, resource ownership, deployment path, or reusable cross-team convention. If no such architectural change occurred, answer: `No context update required.` Otherwise propose a short evidence-cited replacement paragraph for the relevant `context/systems/*.md`. Do not rewrite whole documentation or promote revisions without human review.
