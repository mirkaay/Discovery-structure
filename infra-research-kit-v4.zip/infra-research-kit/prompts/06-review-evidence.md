# Prompt 06 — Red-team your architecture report

Report to audit: **[paste an earlier answer or attach approved evidence note]**.

Act as a skeptical reviewer. For EVERY significant connection and operational assertion, check that there is an actual repo + path + line/symbol source, documentation, or runtime observation. Explicitly flag:
- invented file paths or line numbers;
- HCL resource declarations incorrectly treated as deployed state;
- variables assumed to have values not present in sources;
- unrelated same-name resources combined;
- a Helm chart reference mistaken for a running Operator;
- Dynatrace OneAgent/ActiveGate deployment conflated with private Synthetic execution infrastructure;
- stale, disabled or example pipelines treated as active;
- inferred network routes, token scopes, alerts or notifications.

Output a table: claim | evidence offered | can it be verified? | status (verified/inferred/unknown/incorrect) | corrected language | next cheapest safe check. Calculate % of key claims with credible references. Do not fill unknowns with plausible stories.
