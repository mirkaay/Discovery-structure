# Lean feature request — use Feature Engineer

TASK: [Feature or bug + expected behavior]
SCOPE: [System/repo, if known]
ACCEPTANCE: [What must work and what must not change]
OPTIONAL GIT DELTA: [Output of `python3 scripts/context_status.py check --repo REPO --max-paths 8`]

Classify LIGHT / STANDARD / DEEP. Begin with `context/index.md` to find only the relevant short system note (skip it if unrelated), then inspect the actual affected code, immediate callers and tests. If revision data shows drift, examine only changed files intersecting the feature. Treat notes as navigation, not authority.

For LIGHT/STANDARD, if I explicitly asked you to implement, state the proposed scope briefly then make the smallest maintainable code/test change within my authorized development checkout. If DEEP/high-risk/uncertain, provide a bounded plan and seek approval first. If my request is to plan only, do not edit. Do not run commands, deploy, push, create dead code, add unnecessary dependencies, or refactor unrelated paths.

End with: changed paths, test commands (not claimed as run), risks/unknowns, and whether any architecture summary needs a small update. Keep concise. Only deepen the explanation if I ask.
