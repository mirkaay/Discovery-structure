# Prompt 05 — Read-only SRE incident simulation

Use the verified architecture of **[target]**. Interview me without giving the solution in advance.

Choose a realistic symptom (for example: a Dynatrace Synthetic monitor shows failures while AKS pods appear healthy). Introduce only observations that could logically exist in the verified architecture. Ask for my first investigative action, the signal I expect, and how that evidence would alter my hypotheses. Wait for each answer.

Progress through: incident framing -> impact and timeline -> observability signals -> competing hypotheses -> read-only isolation across DNS/TLS/auth/ingress/operator/monitor location -> mitigation options requiring approval -> verification -> durable prevention.

At each reply, grade me 0–3 on technical accuracy, evidence quality and production safety. Push back on guesses. After 6–8 turns, provide an annotated ideal diagnostic decision tree and three targeted foundation lessons. Do not actually run tools, reveal secrets or change cloud infrastructure.
