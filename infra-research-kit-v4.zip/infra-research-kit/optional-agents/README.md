# Optional roles preserved from v2

These older specialist definitions are intentionally **outside `.github/agents`**, so they are not active in the default Copilot agent picker.

They were preserved for reference, not deleted. If you genuinely need separate teaching, runtime discovery, planning or implementation roles, copy the desired `.md` file into `.github/agents/<name>.agent.md`, then verify tool permissions in the Copilot UI and test agent discovery. The active **Feature Engineer** replaces separate Planner + Implementer for LIGHT/STANDARD work. Read-only Code Reviewer and Architecture Researcher remain selectable for escalation.
