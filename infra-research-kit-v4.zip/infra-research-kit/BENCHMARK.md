# Cost / quality acceptance test

**No measured savings are claimed.** These files do not provide access to Copilot's billing or token counters. Enter observed values from the UI/organization-approved reports manually in `templates/copilot-usage-log.csv`.

1. Pick **three comparable real tasks** with tests: a trivial fix, a bounded feature, and a cross-repo feature. Avoid production-sensitive inputs.
2. For each, compare a fresh chat with your previous workflow against the v3 **Feature Engineer** flow. Use the same model, same branch/revisions, same task and same acceptance tests. Revert only in an authorized development checkout between experiments; don't risk production or data.
3. Record actual credits/tokens when available, number of agent turns, focused tests passing, reviewer defects, unneeded files touched and total time. Report credit totals as UNKNOWN if the UI does not expose them—never estimate token cost by counting Markdown characters.
4. Prefer the workflow with fewer credits *at equal correctness*. For the third task, an extra review can be worth the cost.

Expect the greatest savings on repeated work in known modules. A stale architecture note, overly large index or verbose recurring instructions can cost more than targeted fresh search. Refresh notes selectively. Tool/harness behavior and caching vary by plan and deployment.
