# Verified architectural decisions (maintained by an engineer)

Only capture decisions that affect future implementation. Reference PR/ADR/code evidence and Git revision. Do not infer a decision from a mere implementation pattern.

| Date | System | Decision/constraint | Evidence | Status |
| --- | --- | --- | --- | --- |
| TBD | TBD | TBD | TBD | UNVERIFIED |
