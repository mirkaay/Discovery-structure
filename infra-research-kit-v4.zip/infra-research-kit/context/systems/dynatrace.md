# Dynatrace / AKS — architecture context (TEMPLATE; NOT VERIFIED)

Status: **NOT REVIEWED — placeholders, not facts**
Reviewed on: TBD
Relevant Git revisions: see `context/revisions.json` after review

## Purpose and boundaries
TBD — one paragraph; list environment scope, services and monitoring goals.

## Entry points and ownership
| Repo/revision | Path/symbol | Purpose | Evidence | Confidence |
| --- | --- | --- | --- | --- |
| TBD | TBD | TBD | TBD | UNKNOWN |

## Proven topology and integration paths
TBD — separate deployment/control flow from runtime telemetry and Synthetic execution; mark edges with evidence.

## Reusable coding conventions and tests
TBD — specific module conventions, pipelines, approved commands. Cite location and revision.

## Known hazards and constraints
TBD — security, state changes, releases, backwards compatibility, known ownership boundaries.

## Open questions / runtime evidence
TBD — distinguish missing code evidence, runtime verification and assumptions.

## Changes since previous snapshot
TBD — changed modules, removed paths, replacement references, date and reviewer.
