# Approved architecture context index

> This is a **navigation index**, not production truth. Repository code and observed runtime state are authoritative for their respective claims. All placeholders MUST be filled after authorized discovery. Keep this under ~300 words.

| System | One-page context | Key checkouts | Owners/entry points | Last reviewed |
| --- | --- | --- | --- | --- |
| Dynatrace / AKS | `systems/dynatrace.md` | TBD | TBD | NOT REVIEWED |

## When a feature request arrives

1. Read only the row relevant to the feature and its system page.
2. Inspect `context/revisions.json` or run `python3 scripts/context_status.py check` **manually**; no revisions file means UNVERIFIED.
3. Validate changed paths, active entry points, callers and tests against current code. Do a targeted refresh when drift is found.
4. Read or update `context/decisions.md` only when a recorded decision matters. Do not load every system note.

## Rules

- Cite repository path + revision for claims; do not treat generated diagrams as evidence.
- Production runtime is never proven by Git revision alone.
- Store all company-relevant notes only in approved company-managed locations.
