# Dynatrace + AKS + Terraform investigation matrix

These are **questions** rather than statements about your deployment.

## Ownership and installation
- Does Terraform manage the Azure infrastructure, Dynatrace settings, Helm releases, or a mix? Which Terraform provider and version? Which root module is active? How is state secured, and which pipelines call which roots?
- Is Dynatrace Operator used? Which Operator version, namespace, release source, admission webhook, DynaKube CR name, and monitoring mode? Verify code and runtime separately.
- Which app workloads and namespaces are instrumented? Can pod mutation/injection fail? How are cluster identity, Kubernetes API, network policy and TLS involved?
- What is OneAgent's and ActiveGate's role in this setup? Do not infer Synthetic execution from their mere existence.

## Synthetics: choose ONE existing HTTP or browser monitor
- Find `dynatrace_http_monitor` or `dynatrace_browser_monitor` (or another method, e.g. Settings 2.0 APIs); identify the actual configuration source, schedule, frequency, success validation, thresholds, tags, credentials references, and lifecycle.
- Which public or private Synthetic location IDs are configured? Are their **resolved locations** shown anywhere? Private locations may require separate Synthetic-enabled ActiveGates or Kubernetes containerized execution configurations. AKS being monitored does not prove the monitor executes inside it.
- Trace the monitor -> request -> DNS / egress / proxy -> endpoint / auth -> result -> outage/performance threshold -> problem -> notification/workflow/SLO. Mark any disconnected part UNKNOWN.
- Separate Dynatrace API provider auth, ActiveGate/OneAgent connectivity, Synthetic monitor authentication to application, and notification destination credentials.

## Three required diagrams
1. Desired/config control path (Git -> pipeline -> Terraform/provider/Helm -> API/cluster).
2. Runtime telemetry path (workload instrumentation -> backend -> visibility).
3. Synthetic execution and incident path (location -> endpoint -> results -> problem -> routing).

## Verification (with explicit company authorization only)
- Terraform source configuration and commit; pipeline job metadata; Kubernetes object existence/conditions; Helm releases and installed CRDs; Dynatrace actual Synthetic location type and execution results; current alert routing and problems.
- Never accept `terraform plan` as pure read-only: it can refresh state, call APIs and have security/locking implications. Avoid by default for an investigative agent.
- Never read .tfstate, secret payloads or log bodies that might contain identifiers or sensitive customer data.

Primary public references:
- https://docs.dynatrace.com/docs/dynatrace-intelligence/dynatrace-mcp
- https://docs.dynatrace.com/docs/observe/digital-experience/synthetic/synthetic-app/private-locations
- https://registry.terraform.io/providers/dynatrace-oss/dynatrace/latest/docs/resources/http_monitor
