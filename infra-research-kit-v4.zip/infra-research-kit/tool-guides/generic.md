# Generic integration investigation checklist

Use the same inquiry structure for Splunk, Gremlin, Vault, Argo CD, Azure Monitor, Jenkins, etc.

- Purpose: business capability and failure impact.
- Ownership: Git repo, root module, provider/SDK, service account and approvals (never secrets).
- Desired state: resource declaration, callers, dependency graph, variables and environment overrides.
- Control path: who triggers updates, deployment order, rollback and drift handling.
- Runtime: processes/containers/managed services, DNS, TLS, identity and network boundaries.
- Data path: source -> collection/transformation -> destination -> consumers, retention and permissions.
- Operational signals: golden signals, alerts, SLOs, dashboards, on-call and runbook links.
- Failure model: competing explanations and read-only discriminating observations.
- Evidence: path + line + revision; observed runtime separately; mark unknowns.
- Learning: explain three underlying protocols/concepts and build a small synthetic lab.
