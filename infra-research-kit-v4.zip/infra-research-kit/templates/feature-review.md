# Diff review — [title]

Plan and acceptance criteria:
Actual files changed / diff reference:
Tests actually run and results (or NOT RUN):

| Severity | Evidence (path/line) | Concrete defect | Minimal recommended fix |
| --- | --- | --- | --- |
| TBD | TBD | TBD | TBD |

Review: behavior, edge cases, errors, compatibility, unnecessary abstraction, dead code, security, Terraform state/replacement risk, tests, rollback.

Verdict: INSUFFICIENT EVIDENCE / NEEDS CHANGES / PASS
Stale context findings and proposed documentation update:
