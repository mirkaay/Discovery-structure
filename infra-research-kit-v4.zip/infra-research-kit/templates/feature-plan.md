# Feature implementation plan — [title]

Request / business outcome:
Acceptance criteria (observable):
Target repository / branch / revision:
Cached context read / current context status:
Affected entry points / callers / tests (with evidence):
Proposed minimal change and rationale:
Alternative rejected and reason:
Files permitted to change:
Files explicitly out of scope:
Behavior/invariants / compatibility:
Risk, data/security impact, rollback:
Validation commands evidenced by CI/docs:
Blockers / required approvals:

APPROVAL: [NOT APPROVED — don't edit]
