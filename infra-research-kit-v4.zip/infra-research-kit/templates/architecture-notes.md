# Architecture notebook — [system] / [environment]

- Date, scope, approved storage:
- Current commit SHAs or version tags:
- Known source folders:
- What I can explain without AI:

## Diagram
```mermaid
flowchart LR
  A[Git config] --> B[Pipeline]
  B -. unverified .-> C[Target service]
```

## Evidence ledger
| Claim | Status | Source repo:path:line/revision | Runtime evidence | Unknown / next validation |
| --- | --- | --- | --- | --- |

## Control path

## Runtime / telemetry path

## Alerts / consumer path

## Three things I misunderstood

## Three failure modes I can explain

## Lab exercise with entirely synthetic resources
