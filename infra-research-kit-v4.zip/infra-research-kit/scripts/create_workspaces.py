#!/usr/bin/env python3
"""Create VS Code multi-root research workspaces without copying or moving checkouts."""
import importlib.util
import json
from pathlib import Path
BASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('context_status', Path(__file__).with_name('context_status.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
repos = mod.checkouts()
if not repos:
    raise SystemExit('No configured repos. Run: python3 scripts/context_status.py init --groups dynatrace gremlin')
by_group = {}
for name, path in repos.items():
    group = name.split('/')[0] if '/' in name else 'legacy'
    by_group.setdefault(group, []).append((name, path))
out = BASE / 'workspaces'
out.mkdir(exist_ok=True)
for group, members in sorted(by_group.items()):
    folders = [{'name': 'Research Kit', 'path': '..'}]
    for name, path in members:
        folders.append({'name': name, 'path': __import__('os').path.relpath(path, start=out)})
    ws = {'folders': folders, 'settings': {'search.exclude': {
        '**/.terraform': True, '**/node_modules': True, '**/.git': True,
    }}}
    dest = out / f'{group}.code-workspace'
    dest.write_text(json.dumps(ws, indent=2) + '\n', encoding='utf-8')
    print(dest)
