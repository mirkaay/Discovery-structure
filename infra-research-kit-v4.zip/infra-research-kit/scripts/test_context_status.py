"""Self-contained fixture tests; does not access company repositories."""
import importlib.util
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

MODULE = Path(__file__).with_name('context_status.py')


class StatusFixtureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        (root / 'sources').mkdir()
        (root / 'context').mkdir()
        (root / 'scripts').mkdir()
        shutil.copyfile(MODULE, root / 'scripts/context_status.py')
        self.root = root
        self.repo = root / 'sources' / 'example'
        self.repo.mkdir()
        self.git('init', '-q')
        self.git('config', 'user.name', 'Fixture')
        self.git('config', 'user.email', 'fixture@example.invalid')
        (self.repo / 'main.tf').write_text('resource "null_resource" "example" {}\n')
        self.git('add', 'main.tf')
        self.git('commit', '-qm', 'initial')

    def git(self, *args):
        return subprocess.run(['git', '-C', str(self.repo), *args], check=True,
                              capture_output=True, text=True).stdout.strip()

    def cli(self, *args):
        return subprocess.run(['python3', str(self.root / 'scripts/context_status.py'), *args],
                              capture_output=True, text=True)

    def test_capture_then_change_detects_stale(self):
        self.assertEqual(self.cli('check').returncode, 2)
        self.assertNotEqual(self.cli('capture').returncode, 0)
        self.assertEqual(self.cli('capture', '--reviewed').returncode, 0)
        data = json.loads((self.root / 'context/revisions.json').read_text())
        self.assertEqual(len(data['repositories']), 1)
        self.assertEqual(self.cli('check').returncode, 0)
        (self.repo / 'main.tf').write_text('resource "null_resource" "updated" {}\n')
        result = self.cli('check')
        self.assertEqual(result.returncode, 3)
        self.assertIn('main.tf', result.stdout)
        self.assertNotEqual(self.cli('capture', '--reviewed').returncode, 0)
        self.git('add', 'main.tf')
        self.git('commit', '-qm', 'changed resource')
        result = self.cli('check')
        self.assertEqual(result.returncode, 3)
        self.assertIn('main.tf', result.stdout)
        self.assertEqual(self.cli('capture', '--reviewed').returncode, 0)
        self.assertEqual(self.cli('check').returncode, 0)

    def test_scoped_check_and_limited_paths(self):
        self.assertEqual(self.cli('capture', '--reviewed').returncode, 0)
        (self.repo / 'main.tf').write_text('resource "null_resource" "changed" {}\n')
        (self.repo / 'extra.tf').write_text('locals {}\n')
        result = self.cli('check', '--repo', 'example', '--max-paths', '1')
        self.assertEqual(result.returncode, 3)
        self.assertIn('... and 1 other paths', result.stdout)
        self.assertNotIn('main.tf', result.stdout)
        self.assertEqual(self.cli('check', '--repo', '../example').returncode, 2)
        self.assertEqual(self.cli('check', '--repo', 'missing').returncode, 2)

    def test_untracked_work_blocks_capture(self):
        (self.repo / 'untracked.py').write_text('print("hello")\n')
        self.assertNotEqual(self.cli('capture', '--reviewed').returncode, 0)


class SiblingLayoutTests(unittest.TestCase):
    """Verifies the user's actual dev/<tool>/<repo> layout."""
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        dev = Path(self.temp.name) / 'dev'
        dev.mkdir()
        self.kit = dev / 'infra-research-kit'
        (self.kit / 'scripts').mkdir(parents=True)
        (self.kit / 'context').mkdir()
        shutil.copyfile(MODULE, self.kit / 'scripts/context_status.py')
        shutil.copyfile(MODULE.with_name('create_workspaces.py'), self.kit / 'scripts/create_workspaces.py')
        self.dyna = dev / 'dynatrace' / 'dyna-config'
        self.grem = dev / 'gremlin' / 'chaos-platform'
        for repo in [self.dyna, self.grem]:
            repo.mkdir(parents=True)
            for cmd in [('init', '-q'), ('config', 'user.name', 'Fixture'),
                        ('config', 'user.email', 'fixture@example.invalid')]:
                subprocess.run(['git', '-C', str(repo), *cmd], check=True, capture_output=True)
            (repo / 'main.tf').write_text('locals {}\n')
            subprocess.run(['git', '-C', str(repo), 'add', 'main.tf'], check=True)
            subprocess.run(['git', '-C', str(repo), 'commit', '-qm', 'init'], check=True)

    def cli(self, *args):
        return subprocess.run(['python3', str(self.kit / 'scripts/context_status.py'), *args],
                              capture_output=True, text=True)

    def test_external_workspace_and_scoped_revisions(self):
        r = self.cli('discover')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn('dynatrace/dyna-config', r.stdout)
        self.assertIn('gremlin/chaos-platform', r.stdout)
        r = self.cli('init', '--groups', 'dynatrace', 'gremlin')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(self.cli('list').returncode, 0)
        r = subprocess.run(['python3', str(self.kit / 'scripts/create_workspaces.py')],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        work = json.loads((self.kit/'workspaces/dynatrace.code-workspace').read_text())
        self.assertEqual(len(work['folders']), 2)
        self.assertEqual((self.kit/'workspaces'/work['folders'][1]['path']).resolve(), self.dyna)
        self.assertEqual(self.cli('capture', '--reviewed').returncode, 0)
        (self.dyna / 'main.tf').write_text('locals { changed = true }\n')
        r = self.cli('check', '--tool', 'dynatrace')
        self.assertEqual(r.returncode, 3, r.stderr)
        self.assertIn('main.tf', r.stdout)
        r = self.cli('check', '--tool', 'gremlin')
        self.assertEqual(r.returncode, 0, r.stderr)
        r = self.cli('check', '--repo', 'dynatrace/dyna-config')
        self.assertEqual(r.returncode, 3, r.stderr)



if __name__ == '__main__':
    unittest.main()
