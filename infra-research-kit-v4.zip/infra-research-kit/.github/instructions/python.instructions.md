---
applyTo: "**/*.py"
---

Python guidance for approved feature edits:
- Mirror existing import layout, type conventions, package organization and test framework.
- Prefer small testable functions and explicit error handling; avoid unused imports, duplicate utilities, hidden side effects, broad bare `except`, premature abstractions and unnecessary packages.
- Validate untrusted input at existing trust boundaries; do not log secrets or sensitive payloads.
- Cover changed behavior with focused positive and negative tests. Only recommend test commands found in project docs/CI.
