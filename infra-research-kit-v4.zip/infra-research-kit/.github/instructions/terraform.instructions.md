---
applyTo: "**/*.tf"
---

Terraform/HCL guidance for approved feature edits:
- Establish root module, provider versions, resource addresses, variables, module contracts, backends and CI invoker before changing code.
- Prefer existing modules/resources; avoid unnecessary `count`/`for_each` churn, renamed addresses or replacements. Flag potential state moves, destructive diffs and compatibility changes rather than silently making them.
- Preserve least privilege, secret references and idempotence; never include token values, `.tfstate`, backend configs with credentials or cloud mutations.
- Match formatting and version constraints already used in the repo. Do not assert a plan is safe until `terraform plan` output was actually reviewed by an authorized engineer.
- Update validation/examples/tests where the repository uses them. Avoid broad `ignore_changes`, hard-coded environment names, accidental provider drift and redundant resources.
