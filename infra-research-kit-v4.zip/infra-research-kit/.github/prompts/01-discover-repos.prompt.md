---
name: 01-discover-repos
description: Read-only infrastructure research workflow 01-discover-repos
agent: agent
---

# Prompt 01 — Repository reconnaissance and architecture inventory

Target system: **[Dynatrace monitoring for AKS; replace for other tools]**.
Scope: **[list source folder names or the lab-fixture]**. Environment: **[dev/stage/prod/unknown]**.

You are an evidence-driven architecture researcher. Read only; do not execute commands or edit files. Search the provided workspace for actual, active configuration relating to the target system. Do not assume that every repository participates in deployment.

**Pass 1 — inventory:** Enumerate candidate Terraform root modules and their module calls; provider declarations and aliases; variables/outputs; AKS Kubernetes manifests, Helm chart references and CRDs; pipeline files; synthetic resources; dashboard/alert integration; identity and secret reference mechanisms (not secret values); documentation or runbooks. Also find references to the same resource IDs across folders. Indicate when no evidence exists.

**Pass 2 — prove relationships:** For each candidate connection, find both caller and callee (e.g. Terraform module source, pipeline working directory, Helm values file, resource reference). Distinguish live/referenced artifacts from dead/example code, and account for environment-specific overrides. Do not call unused configuration deployed.

**Pass 3 — synthesize:** Return:
1. Source coverage table: repository, file/pattern, responsibility, active? evidence link or line, ambiguity.
2. A Mermaid diagram with **solid arrows for verified links** and **dashed arrows for hypotheses**. Mark runtime flow separately from deployment flow.
3. Inventory of Terraform and Kubernetes resources; distinguish native Azure, Dynatrace Terraform provider and Kubernetes providers.
4. Dependency/ownership table and likely order of operations.
5. A prioritized list of 10 specific unknowns and **safe read-only** evidence needed to close each.
6. Two concrete candidates for a subsequent single-path trace, with rationales.
7. Concepts the engineer must understand to explain the system.

Do not infer resolved values of secrets, Terraform variables or runtime state. Include repo relative paths and exact line numbers when available. Quote only short non-secret identifiers. Stop if the scope is too wide and recommend one smaller slice rather than providing generic explanations.
