---
description: implement approved plan
---

# Implement an approved scoped feature

Use **Feature Implementer** (read/search/edit; no execute), only after plan approval.

APPROVED PLAN: [paste or attach the reviewed `templates/feature-plan.md`]
TARGET REPOSITORY/BRANCH: [details]

Re-check the named files and current dependencies; stop if the approved plan no longer fits. Make the smallest code and test diff that satisfies acceptance criteria. Mirror codebase conventions. Do not add speculative abstractions, unused code, arbitrary retries, unnecessary dependencies, broad exceptions or unrelated refactoring. Preserve compatibility, security, idempotency and Terraform state/resource addresses. After editing, provide a file-by-file diff summary, remaining unknowns, proposed manual validation commands grounded in repo docs/CI, and a narrow documentation delta. Do not run commands, push, commit, deploy or claim tests passed.
