---
description: Efficient feature/bug work using only relevant current code and cached architecture references.
---

Follow `prompts/09-feature-request.md`. My request: ${input:request:Describe the feature or bug and acceptance criteria}
