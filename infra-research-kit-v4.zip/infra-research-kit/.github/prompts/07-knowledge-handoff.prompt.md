---
name: 07-knowledge-handoff
description: Read-only infrastructure research workflow 07-knowledge-handoff
agent: agent
---

# Prompt 07 — Produce the lasting learning notes

Based ONLY on the verified findings in this chat, produce copy-ready Markdown with these sections:
1. Scope (environment, date, repo versions, source coverage).
2. One-page architecture with Mermaid diagram, marking hypothetical edges.
3. Deployment/control path, runtime path, telemetry path, alert/notification path.
4. Evidence ledger (each company-specific claim and source).
5. Operational failure modes and safe, read-only verification checks.
6. Security/trust boundaries with NO secret values or sensitive telemetry.
7. Ten important concepts, explained in my own words as much as possible; mark knowledge not yet demonstrated.
8. Remaining unknowns with specific owner or observation needed.
9. Three teach-back questions and a mini public lab.
10. What changed since the last study session, if known.

Do not imply verification you did not perform. Never save files automatically. I will review, redact and store in a permitted location.
