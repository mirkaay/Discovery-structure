---
description: review implementation
---

# Independent implementation review

Use **Code Reviewer** (read/search only).

APPROVED PLAN: [attach approved plan]
ACTUAL DIFF: [attach diff or specific changed files; not just the model's summary]
TEST RESULTS: [paste actual output or state NOT RUN]

Independently review requirements, edge cases, security, changed callers, API stability, complexity, error handling, duplication, dead/unreachable code, unnecessary modules/dependencies, and performance implications only where justified. For Terraform, note state migration, resource replacement and provider drift risk. Compare implementation with existing patterns, not generic code-style preferences. Prioritize only actionable findings with path/line and failure mechanism. Verdict PASS / NEEDS CHANGES / INSUFFICIENT EVIDENCE. Mention any documented architecture assumptions invalidated by the diff.
