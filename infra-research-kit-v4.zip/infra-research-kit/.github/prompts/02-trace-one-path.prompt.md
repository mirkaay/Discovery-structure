---
name: 02-trace-one-path
description: Read-only infrastructure research workflow 02-trace-one-path
agent: agent
---

# Prompt 02 — Trace a single resource end to end

Target **one** object: **[monitor name/resource, DynaKube, Helm release or pipeline]**.
Known entry point: **[file path / identifier]**. Environment: **[target]**.

Find the declaration and trace its creation and behavior across real paths. I need *causal evidence*, not a collection of loosely related files.

For each step identify:
- Input, output and exact code symbol/reference; repo/path/line/commit where possible.
- Which tool/provider/API/service acts; which identity authenticates (mechanism only, no secrets).
- Where the value comes from (variable default, tfvars, variable group, environment, secret reference), and whether resolved values are available.
- Pipeline trigger, conditions, working directory, environment selection, plan/apply boundaries and manual approvals, only if evidenced.
- Runtime components and network direction (DNS, proxy, TLS, ingress/egress) only where proven.
- Runtime telemetry or Synthetic execution location, result, problem/alert route, and what is NOT proved by code.

Deliver five separate flows: (A) Terraform desired state; (B) deployment/control-plane execution; (C) AKS runtime; (D) monitor execution/telemetry; (E) problem-to-notification. Do NOT force a connection if the code doesn't prove it. Give a relationship/evidence ledger with claim, status, exact reference and next verification. Explain likely design motivations only as inferences, with alternatives and tradeoffs.

Finish by answering: What would change if I removed this resource from Terraform? What could continue running unaffected? What would break if DNS, TLS, tokens, private execution location or network access were unavailable? Clearly mark hypothetical scenarios.
