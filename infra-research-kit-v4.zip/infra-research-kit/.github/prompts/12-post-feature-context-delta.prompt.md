---
description: post feature context delta
---

# Update persistent context after feature delivery

Use Context Maintainer, read/search only. Take the approved diff and independently reviewed evidence. Identify whether it actually changes an architectural edge, ownership, API contract, operational constraint, CI path, or reusable coding convention. If not, reply "No architecture update required". If yes, provide a minimal proposed amendment to `context/systems/<system>.md` or `context/decisions.md`, with current revision and citations. Do not automatically promote a monthly snapshot or rewrite all architecture docs.
