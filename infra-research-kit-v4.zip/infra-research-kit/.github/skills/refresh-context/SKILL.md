---
name: refresh-context
description: Diff the current Git revisions against an approved architecture snapshot, refresh only affected systems, and prepare a reviewed context update.
---

1. Read `context/index.md` and the relevant system page; identify stored source revisions and entry points.
2. Request or consume output of `python3 scripts/context_status.py check`. The user, not the read-only agent, runs the command.
3. If HEAD differs, inspect changed file list and target code, then trace only changed edges. Check renamed resources, modules, CI, interfaces, security boundaries and tests.
4. Output **draft** context page and evidence table with revisions. Mark unverified runtime claims clearly.
5. Engineer verifies, saves draft into `context/systems/`, updates index if ownership changed, then runs `python3 scripts/context_status.py capture --reviewed` manually. The metadata command does not verify document truth; review must happen first.
6. Monthly full sweep plus immediate refresh on major changes, critical PRs or missing/broken evidence. Never label stale docs fresh based solely on date.
