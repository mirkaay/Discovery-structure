---
name: trace-integration
description: Trace an infrastructure tool or integration end to end across Terraform, Kubernetes, deployment pipelines and monitoring with cited source evidence and explicit unknowns. Use when mapping how a system works.
---
# Cross-repository integration tracing

1. Define a narrow target (one monitor, cluster, pipeline, service or named configuration) and list candidate repositories.
2. Search by exact identifiers first, semantic search second. Inspect active root modules, their callers, environment mappings and deployment workflows.
3. Build separate chains: desired configuration -> deployment execution -> runtime components -> telemetry/event path -> alerts and consumers.
4. For each arrow, show **source evidence on both ends or the specific link between them**; note when a variable, API reference, or identity crosses repository boundaries.
5. Call out gaps such as unresolved sensitive variables (never reveal contents), external release artifacts, state backend not observed, or UI-managed config not in code.
6. Return concise architecture diagram (Mermaid), dependency table, verified/unknown evidence ledger, 5 safe runtime verification checks, and 3 concepts to learn.
7. Require user confirmation before promoting anything to persistent notes.
