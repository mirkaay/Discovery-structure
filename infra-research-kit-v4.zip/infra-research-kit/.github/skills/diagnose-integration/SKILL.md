---
name: diagnose-integration
description: Form source-grounded, read-only troubleshooting hypotheses for broken infrastructure, telemetry and Synthetic monitoring paths, without changing cloud or Kubernetes resources.
---
# Hypothesis-driven troubleshooting without production changes

1. Identify a symptom precisely and name the user-facing impact and observed evidence.
2. Draw a minimal path from signal source to destination; mark trust/network/control boundaries.
3. List at least three competing failure hypotheses, separating upstream outage, instrumentation failure, and monitoring execution failure.
4. For each hypothesis define the expected signal, safest read-only validation and what would falsify it.
5. Rank checks by diagnostic value, minimum access and production risk. Never ask to print secrets or production-sensitive payloads.
6. Summarize the current most likely explanation as a hypothesis, not a fact. Teach the relevant DNS/TLS/Kubernetes/provider fundamentals.
