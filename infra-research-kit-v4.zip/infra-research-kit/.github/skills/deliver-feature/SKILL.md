---
name: deliver-feature
description: Deliver a scoped development request using current code and optional cached architecture context with minimal overhead.
---

Default to **Feature Engineer** alone. Categorize LIGHT / STANDARD / DEEP.

LIGHT: directly locate relevant implementation and tests; 2–3-line plan; edit minimal code on an authorized development checkout if user asked to implement; summarize focused verification.
STANDARD: read only relevant system note and code; check applicable revision deltas; plan briefly; implement minimal code + tests; summarize diff and risk. Optional read-only Code Reviewer if changes are subtle.
DEEP: use Architecture Researcher or Context Maintainer to resolve specific unknowns, document a bounded implementation plan, request approval before edits, and then get independent Code Reviewer feedback. Never automatically spawn every role.

Do not confuse unchanged Git HEAD with unchanged working tree or deployed runtime. Do not rerun broad discovery unless the existing context is missing or materially invalidated. Do not claim tests passed without observed output. The engineer executes approved CI/test commands, not the agent.
