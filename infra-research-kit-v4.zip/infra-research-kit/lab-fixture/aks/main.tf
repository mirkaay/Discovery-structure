# SYNTHETIC, NOT PRODUCTION, NOT APPLIED.
terraform {
  required_providers {
    azurerm = { source = "hashicorp/azurerm", version = "~> 4.0" }
  }
}
resource "azurerm_kubernetes_cluster" "demo" {
  name                = "aks-example-research"
  location            = "canadacentral"
  resource_group_name = "rg-example-research"
  dns_prefix          = "example-research"
  default_node_pool { name = "system", node_count = 1, vm_size = "Standard_D2s_v3" }
  identity { type = "SystemAssigned" }
}
# INTENTIONALLY NO HELM RELEASE, DynaKube OR OPERATOR DEPLOYMENT HERE.
