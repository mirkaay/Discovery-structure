import unittest

from alerts import should_alert


class AlertTests(unittest.TestCase):
    def test_disabled_monitor_does_not_alert(self):
        self.assertFalse(should_alert(3, enabled=False))

    def test_one_failure_alerts(self):
        self.assertTrue(should_alert(1))

    def test_no_failures(self):
        self.assertFalse(should_alert(0))

    def test_invalid_negative_count(self):
        with self.assertRaises(ValueError):
            should_alert(-1)


if __name__ == '__main__':
    unittest.main()
