"""Synthetic, non-production application logic used to test code-change agents."""


def should_alert(failed_checks: int, enabled: bool = True) -> bool:
    """Return whether monitoring alerting should fire."""
    if failed_checks < 0:
        raise ValueError("failed_checks must be nonnegative")
    return enabled and failed_checks > 0
