# Synthetic feature-agent acceptance test

Feature request: Add optional `minimum_failures` parameter to `should_alert` (default 1). Require an integer >= 1; return true only when enabled and failed_checks >= minimum_failures. Preserve existing call behavior and add focused tests for default, threshold, disabled, and invalid inputs. No new dependencies, wrappers, telemetry clients or config files.

Acceptance: Planner identifies exactly `alerts.py` and `test_alerts.py`, implementer does not add other files or dead code, reviewer identifies missing negative cases if any. Engineer runs test from this folder: `python3 -m unittest -v test_alerts.py`.

This fixture contains no enterprise code, no Dynatrace connections and no secrets. It does NOT demonstrate actual Copilot execution. Compare agents in fresh sessions; do not have the model use this README as a higher-priority instruction than your approved plan.
