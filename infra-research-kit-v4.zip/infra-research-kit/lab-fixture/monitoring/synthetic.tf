# SYNTHETIC EXAMPLE — definition only, never applied.
terraform {
  required_providers {
    dynatrace = { source = "dynatrace-oss/dynatrace", version = "~> 1.0" }
  }
}
variable "synthetic_location_id" {
  type = string
  description = "Supplied outside fixture; no resolved value in these files"
}
resource "dynatrace_http_monitor" "demo" {
  name      = "synthetic-example-health"
  frequency = 5
  locations = [var.synthetic_location_id]
  # Deliberately incomplete: code fixture is for RESEARCH, not deployability.
}
# NO evidence of a private location or any runtime execution location.
