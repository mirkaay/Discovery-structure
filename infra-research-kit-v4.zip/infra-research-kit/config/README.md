# Approved source repository allowlist

Do **not** clone or move repositories into this kit. Keep existing repositories under `dev/<tool>/<repo>` and run:

```bash
python3 scripts/context_status.py discover
python3 scripts/context_status.py init --groups dynatrace gremlin compliance-tool
python3 scripts/context_status.py list
python3 scripts/create_workspaces.py
```

The `init` command writes `config/repositories.json` using paths such as `../dynatrace/dynatrace-terraform` relative to the kit. Review the generated file and remove checkouts you do not want in the research scope. This file is ignored from kit Git to avoid sharing local paths.

Use `python3 scripts/context_status.py check --tool dynatrace --max-paths 8` to inspect changes after a reviewed baseline. Capture the baseline only after reviewing the architecture notes and ensuring the allowlisted repos have clean working copies: `python3 scripts/context_status.py capture --reviewed`.

Existing v3 `sources/` checkouts still work if there is **no** config/repositories.json, but the sibling-folder arrangement is preferred.
