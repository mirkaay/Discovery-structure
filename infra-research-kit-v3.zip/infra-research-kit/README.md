# Infrastructure Research + Feature Delivery Kit v3 (lean default)

**Updated November 10, 2026.** This version replaces the default v2 multi-agent development chain with **one Feature Engineer**, while keeping deep infrastructure discovery and independent review available when justified. It does **not** guarantee token savings; see `BENCHMARK.md` for a repeatable measurement method.

## What changed from v2

- **Four active agents:** `Feature Engineer` (the daily default), `Architecture Researcher`, `Context Maintainer`, `Code Reviewer` (optional). Five original specialist agents are archived as plain Markdown in `optional-agents/` and are not auto-listed as agent definitions.
- **Shorter global instructions:** only core guardrails, evidence standards, and minimal-context rules.
- **Three effort levels:** LIGHT and STANDARD use one agent in one session; DEEP uses a reviewed plan, optional targeted research and independent review.
- **Incremental context checks:** `python3 scripts/context_status.py check --repo REPO --max-paths 8` allows a compact report for just the relevant checkout. The unchanged full `check` and manually reviewed `capture --reviewed` commands are preserved.
- **Cost benchmark:** `BENCHMARK.md` and `templates/copilot-usage-log.csv` for recording actual Copilot usage and quality before claiming savings.
- **Existing architecture research prompts, skills, context templates and test fixture are retained.** Unused files are not automatically included in a model request just because they exist on disk; what is loaded depends on actual session context and harness.

## Start here — feature or bug request

1. Open this kit as a single folder in an **organization-approved** VS Code/Copilot deployment. Keep only authorized local checkouts under `sources/<repo>/` and do not upload proprietary code to personal services. This ZIP contains no company repos.
2. Run `python3 scripts/context_status.py check --repo YOUR_REPO --max-paths 8` manually, when you have an approved baseline. If no baseline exists, don't assume any architecture note is verified.
3. Select **Feature Engineer** in Copilot and use `prompts/09-feature-request.md` with your request.
4. LIGHT/STANDARD: agent inspects relevant code and tests, writes a short plan and makes minimal scoped edits **only when you explicitly requested implementation**. No forced agent handoffs.
5. Run the project's actual lint/tests/CI manually. For subtle or risky changes, select **Code Reviewer** using `prompts/11-review-implementation.md`.
6. Update a system note only when implementation genuinely changed the architecture; otherwise skip documentation updates.

## For Dynatrace / AKS research

Use **Architecture Researcher** and `prompts/01-discover-repos.md` for an initial reviewed discovery, or `prompts/02-trace-one-path.md` for a single monitor. Save short reviewed notes under `context/systems/`, anchored to source paths and repository revisions. Keep production/runtime hypotheses separate from code-proven topology. Use **Context Maintainer** monthly or after material changes, but review changed files rather than redoing all discovery.

## Scope and security

This kit uses documentation-based behavioral constraints, not a security sandbox. The Feature Engineer has `read`, `search`, and `edit` tools; other active agents are read/search only. Read the permissions shown by your actual Copilot harness. No role is given execute tools, and agents must not run Terraform, deploy, push, merge, access production, or retrieve secrets. Real CI and human review are the enforcement mechanisms. Organizational policy and approved data boundaries always win.

## Compatibility

Designed for VS Code GitHub Copilot custom agent format and skills. Your VS Code version is 1.122.1 Universal; confirm feature support and agent discovery before relying on the setup. Plain prompts in `prompts/` work as copy/paste fallback; `.github/prompts/*.prompt.md` may be harness-specific. This kit was **locally tested for file structure and revision-tracker behavior**, not against your employer's Copilot instance.

## Validate locally

```bash
python3 scripts/validate_kit.py
python3 -m unittest -v scripts/test_context_status.py
```

The synthetic fixture at `lab-fixture/` can be used to challenge architecture claims without company data. See `BENCHMARK.md` for a real-world acceptance test.

## Useful files

- `context/index.md` — navigation-only index; never authoritative without checking code
- `.github/copilot-instructions.md` — short always-on standards
- `.github/agents/feature-engineer.agent.md` — one daily agent
- `prompts/09-feature-request.md` — typical work
- `scripts/context_status.py` — local revision delta reporting
- `BENCHMARK.md` — verify savings empirically
- `optional-agents/` — earlier v2 roles retained but not loaded as active agents
- `sources/README.md` — safe source placement

Original full research prompts and guides remain available. Keep all company-specific notes and checkouts in authorized corporate locations.
