#!/usr/bin/env python3
"""Local, stdlib-only Git revision awareness for context snapshots.

Shows metadata and file paths only. Never reads file contents, logs in, fetches,
executes Terraform, or traverses remote services. Run manually in approved workspace.
"""
import argparse
import datetime as dt
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'sources'
BASELINE = ROOT / 'context' / 'revisions.json'
MAX_PATHS = 30


def git(repo, *args, ok_missing=False):
    try:
        result = subprocess.run(
            ['git', '-C', str(repo), *args], check=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=12,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        if ok_missing:
            return None
        raise


def checkouts():
    if not SOURCE.exists():
        return {}
    found = {}
    # Only direct subdirectories of sources/ are treated as approved checkouts.
    # Worktrees (.git as a file) are also supported.
    for path in sorted(SOURCE.iterdir()):
        if path.is_dir() and (path / '.git').exists():
            if git(path, 'rev-parse', '--is-inside-work-tree', ok_missing=True) == 'true':
                found[path.relative_to(ROOT).as_posix()] = path
    return found


def revision_info(path):
    return {
        'sha': git(path, 'rev-parse', 'HEAD'),
        'branch': git(path, 'symbolic-ref', '--quiet', '--short', 'HEAD', ok_missing=True) or '(detached)',
    }


def file_changes(path, baseline_sha):
    if not baseline_sha:
        return ['(no baseline available)'], True
    if git(path, 'cat-file', '-e', baseline_sha + '^{commit}', ok_missing=True) is None:
        return ['(baseline commit no longer present in local repo)'], True
    # Detect divergence by checking whether merge-base equals baseline.
    mb = git(path, 'merge-base', baseline_sha, 'HEAD', ok_missing=True)
    if mb != baseline_sha:
        return ['(branch diverged from stored baseline; review history)'], True
    changed = set(filter(None, (git(path, 'diff', '--name-only', baseline_sha, 'HEAD', ok_missing=True) or '').splitlines()))
    changed.update(filter(None, (git(path, 'diff', '--name-only', ok_missing=True) or '').splitlines()))
    changed.update(filter(None, (git(path, 'diff', '--name-only', '--cached', ok_missing=True) or '').splitlines()))
    untracked = git(path, 'ls-files', '--others', '--exclude-standard', ok_missing=True) or ''
    changed.update(filter(None, untracked.splitlines()))
    return sorted(changed), bool(changed)


def capture(reviewed):
    if not reviewed:
        raise SystemExit('Refusing to promote a baseline without --reviewed; validate and save your context notes first.')
    repos = checkouts()
    if not repos:
        raise SystemExit('No Git checkouts found directly under sources/; nothing to capture.')
    records = []
    dirty = []
    for name, path in repos.items():
        rec = revision_info(path)
        rec['path'] = name
        records.append(rec)
        changes, has_changes = file_changes(path, rec['sha'])
        if has_changes:
            dirty.append(f'{name}: {len(changes)} uncommitted/untracked paths')
    if dirty:
        raise SystemExit('Refusing to capture working copies with outstanding changes:\n' + '\n'.join(dirty))
    data = {
        'captured_at_utc': dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        'notice': 'Commit metadata only; correctness of accompanying notes requires independent human review.',
        'repositories': records,
    }
    BASELINE.parent.mkdir(parents=True, exist_ok=True)
    BASELINE.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    print('CAPTURED approved commit metadata:', BASELINE.relative_to(ROOT))
    for record in records:
        print('  ', record['path'], record['sha'][:12], record['branch'])
    print('REMINDER: This does not verify your architecture notes or deployed runtime.')
    return 0


def check(selected_repo=None, max_paths=MAX_PATHS):
    repos = checkouts()
    if selected_repo:
        # Restrict the selector to a direct child of sources; no path traversal.
        if selected_repo in ('.', '..') or '/' in selected_repo or '\\' in selected_repo:
            print('ERROR: --repo must be a direct checkout folder name under sources/')
            return 2
        key = f'sources/{selected_repo}'
        if key not in repos:
            print(f'ERROR: no checkout at {key}; check sources/README.md')
            return 2
        repos = {key: repos[key]}
    if not BASELINE.exists():
        print('UNVERIFIED: context/revisions.json does not exist; perform reviewed discovery first.')
        if repos:
            for name, path in repos.items():
                print('  checkout:', name, revision_info(path)['sha'][:12])
        else:
            print('  No Git checkouts found directly under sources/')
        return 2
    try:
        baseline = json.loads(BASELINE.read_text(encoding='utf-8'))
        old = {x['path']: x for x in baseline['repositories']}
    except (ValueError, KeyError, TypeError) as exc:
        print('ERROR: malformed baseline:', exc)
        return 2
    print('Baseline captured:', baseline.get('captured_at_utc', '(unknown)'))
    any_stale = False
    names = {f'sources/{selected_repo}'} if selected_repo else set(old) | set(repos)
    for name in sorted(names):
        if name not in old:
            print('STALE (new checkout):', name)
            any_stale = True
            continue
        if name not in repos:
            print('STALE (missing checkout):', name)
            any_stale = True
            continue
        rev = revision_info(repos[name])
        old_sha = old[name]['sha']
        changes, dirty = file_changes(repos[name], old_sha)
        if rev['sha'] == old_sha and not dirty:
            print(f'FRESH AT COMMIT: {name} {rev["sha"][:12]} (does not establish runtime freshness)')
        else:
            any_stale = True
            print(f'STALE: {name} baseline={old_sha[:12]} current={rev["sha"][:12]}')
            for x in changes[:max_paths]:
                print('    changed:', x)
            if len(changes) > max_paths:
                print(f'    ... and {len(changes) - max_paths} other paths')
    return 3 if any_stale else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['check', 'capture'])
    parser.add_argument('--reviewed', action='store_true', help='Human confirms context pages were reviewed before capture.')
    parser.add_argument('--repo', help='For check mode: only this direct child checkout name in sources/ (compact feature context).')
    parser.add_argument('--max-paths', type=int, default=MAX_PATHS, help='For check mode: maximum changed paths to display per repository (default 30).')
    args = parser.parse_args()
    if args.max_paths < 0 or args.max_paths > 1000:
        parser.error('--max-paths must be between 0 and 1000')
    if args.mode == 'capture':
        if args.repo:
            parser.error('--repo is only supported with check; capture records the full reviewed baseline')
        return capture(args.reviewed)
    return check(args.repo, args.max_paths)


if __name__ == '__main__':
    sys.exit(main())
