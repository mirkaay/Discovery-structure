#!/usr/bin/env python3
"""Portable static structural checks. Does NOT prove Copilot uses these files."""
import json
import re
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
base = ROOT / '.github/agents'
research_agents = ['architecture-researcher', 'context-maintainer', 'code-reviewer']
for slug in research_agents:
    p = base / (slug + '.agent.md')
    text = p.read_text()
    assert text.startswith('---\n'), p
    assert re.search(r'^name: .+', text, re.M), p
    assert re.search(r'^description: .+', text, re.M), p
    assert "tools: ['read', 'search']" in text, p
    assert not re.search(r"tools:.*(execute|edit|web|agent|\*)", text), p
impl = (base / 'feature-engineer.agent.md').read_text()
assert "tools: ['read', 'search', 'edit']" in impl
assert not re.search(r"tools:.*(execute|web|agent|\*)", impl)
assert len(list(base.glob('*.agent.md'))) == 4, 'Expect exactly four active agents'
assert len((ROOT/'.github/copilot-instructions.md').read_text().split()) <= 300
assert (ROOT/'BENCHMARK.md').exists()
assert (ROOT/'UPGRADE-FROM-V2.md').exists()
for skill in ['trace-integration', 'diagnose-integration', 'refresh-context', 'deliver-feature']:
    s = (ROOT / '.github/skills' / skill / 'SKILL.md').read_text()
    assert s.startswith('---\n') and 'name: ' + skill in s
for i in range(1, 13):
    assert len(list((ROOT / 'prompts').glob(f'{i:02d}-*.md'))) == 1, i
    assert len(list((ROOT / '.github/prompts').glob(f'{i:02d}-*.prompt.md'))) == 1, i
for f in ['terraform', 'python']:
    s=(ROOT/'.github/instructions'/f'{f}.instructions.md').read_text()
    assert s.startswith('---\n') and 'applyTo:' in s
ws=json.loads((ROOT/'infra-research.code-workspace').read_text())
assert ws['folders'][0]['path'] == '.'
assert (ROOT/'context/index.md').exists() and (ROOT/'context/systems/dynatrace.md').exists()
assert (ROOT/'scripts/context_status.py').exists()
assert 'var.synthetic_location_id' in (ROOT/'lab-fixture/monitoring/synthetic.tf').read_text()
assert not list((ROOT/'lab-fixture').rglob('*.tfstate'))
print('PASS: 3 read-only agents, 1 edit-capable Feature Engineer, 4 skills, 12 prompts + Local wrappers,')
print('      2 scoped instruction files, context templates, workspace JSON and synthetic fixtures.')
print('NOT TESTED: VS Code agent discovery, model behavior, permissions enforcement, live repos/runtime.')
