"""Self-contained fixture tests; does not access company repositories."""
import importlib.util
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

MODULE = Path(__file__).with_name('context_status.py')


class StatusFixtureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        (root / 'sources').mkdir()
        (root / 'context').mkdir()
        (root / 'scripts').mkdir()
        shutil.copyfile(MODULE, root / 'scripts/context_status.py')
        self.root = root
        self.repo = root / 'sources' / 'example'
        self.repo.mkdir()
        self.git('init', '-q')
        self.git('config', 'user.name', 'Fixture')
        self.git('config', 'user.email', 'fixture@example.invalid')
        (self.repo / 'main.tf').write_text('resource "null_resource" "example" {}\n')
        self.git('add', 'main.tf')
        self.git('commit', '-qm', 'initial')

    def git(self, *args):
        return subprocess.run(['git', '-C', str(self.repo), *args], check=True,
                              capture_output=True, text=True).stdout.strip()

    def cli(self, *args):
        return subprocess.run(['python3', str(self.root / 'scripts/context_status.py'), *args],
                              capture_output=True, text=True)

    def test_capture_then_change_detects_stale(self):
        self.assertEqual(self.cli('check').returncode, 2)
        self.assertNotEqual(self.cli('capture').returncode, 0)
        self.assertEqual(self.cli('capture', '--reviewed').returncode, 0)
        data = json.loads((self.root / 'context/revisions.json').read_text())
        self.assertEqual(len(data['repositories']), 1)
        self.assertEqual(self.cli('check').returncode, 0)
        (self.repo / 'main.tf').write_text('resource "null_resource" "updated" {}\n')
        result = self.cli('check')
        self.assertEqual(result.returncode, 3)
        self.assertIn('main.tf', result.stdout)
        self.assertNotEqual(self.cli('capture', '--reviewed').returncode, 0)
        self.git('add', 'main.tf')
        self.git('commit', '-qm', 'changed resource')
        result = self.cli('check')
        self.assertEqual(result.returncode, 3)
        self.assertIn('main.tf', result.stdout)
        self.assertEqual(self.cli('capture', '--reviewed').returncode, 0)
        self.assertEqual(self.cli('check').returncode, 0)

    def test_scoped_check_and_limited_paths(self):
        self.assertEqual(self.cli('capture', '--reviewed').returncode, 0)
        (self.repo / 'main.tf').write_text('resource "null_resource" "changed" {}\n')
        (self.repo / 'extra.tf').write_text('locals {}\n')
        result = self.cli('check', '--repo', 'example', '--max-paths', '1')
        self.assertEqual(result.returncode, 3)
        self.assertIn('... and 1 other paths', result.stdout)
        self.assertNotIn('main.tf', result.stdout)
        self.assertEqual(self.cli('check', '--repo', '../example').returncode, 2)
        self.assertEqual(self.cli('check', '--repo', 'missing').returncode, 2)

    def test_untracked_work_blocks_capture(self):
        (self.repo / 'untracked.py').write_text('print("hello")\n')
        self.assertNotEqual(self.cli('capture', '--reviewed').returncode, 0)


if __name__ == '__main__':
    unittest.main()
